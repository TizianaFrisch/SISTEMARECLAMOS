package com.ar.reclamo.datos;

public interface EdificioRepository {

}
