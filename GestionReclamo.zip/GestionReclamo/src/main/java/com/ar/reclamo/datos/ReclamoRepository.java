package com.ar.reclamo.datos;

public interface ReclamoRepository {

}
