package com.ar.reclamo.datos;

public interface UsuarioRepository {

}
